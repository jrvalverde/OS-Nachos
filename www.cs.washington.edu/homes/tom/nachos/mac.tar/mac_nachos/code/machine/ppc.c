#include <PPCToolBox.h>
#include <GestaltEqu.h>
#include <Script.h>
#include <String.h>
#include <stdio.h>
#include <stdarg.h>

void ShowPPCBrowser(LocationNameRec *theLocation, PortInfoRec *thePortInfo);
pascal void FinishWriteSession(PPCWritePBPtr thePPCReadPBPtr );
extern pascal void FinishReadSession(PPCReadPBPtr thePPCReadPBPtr );

#define	userRejectErr	-912

OSErr DoPPCGetTargetAddress(char *toName, PortInfoPtr thePortInfoRec, LocationNamePtr theLocation ) {
	
	thePortInfoRec->name.nameScript = smRoman;
	strcpy ((char *)thePortInfoRec->name.name, toName);
	c2pstr((char *) thePortInfoRec->name.name);
	thePortInfoRec->name.portKindSelector = ppcByString;
	strcpy ((char *)thePortInfoRec->name.u.portTypeStr,"NACHOS_TYPE");
	c2pstr((char *) thePortInfoRec->name.u.portTypeStr);
	thePortInfoRec->authRequired = FALSE;
	
	theLocation->locationKindSelector = ppcNoLocation;
	
	//ShowPPCBrowser(theLocation, thePortInfoRec);
	
	return(0);
}

// Using the PPCWrite function to write data during a session
OSErr DoPPCWrite(	PPCWritePBPtr	thePPCWritePBPtr,
						PPCSessRefNum	theSessRefNum,
						Size		theBufferLength,
						Ptr			theBufferPtr )
{
	thePPCWritePBPtr->ioCompletion	= (ProcPtr) FinishWriteSession;

	// from the PPCStart function or the PPCInform function--
	thePPCWritePBPtr->sessRefNum	= theSessRefNum;
	thePPCWritePBPtr->bufferLength	= theBufferLength;
	thePPCWritePBPtr->bufferPtr	= theBufferPtr;
	thePPCWritePBPtr->more	= FALSE;   // no more data to read
	thePPCWritePBPtr->userData	= 0;           // app-specific data
	thePPCWritePBPtr->blockCreator	= 0x3f3f3f3f;  // app-specific data
	thePPCWritePBPtr->blockType	= 0x3f3f3f3f;  // app-specific data

	return PPCWrite(thePPCWritePBPtr, TRUE );   // asynchronous
}

// Using the PPCRead function to read data during a session
OSErr DoPPCRead(PPCReadPBPtr	thePPCReadPBPtr,
					PPCSessRefNum	theSessRefNum,
					Size			theBufferLength,
					Ptr			theBufferPtr )

{
	thePPCReadPBPtr->ioCompletion = (ProcPtr) NULL;

	// from the PPCStart function  or the PPCInform function:
	thePPCReadPBPtr->sessRefNum	= theSessRefNum;
	thePPCReadPBPtr->bufferLength	= theBufferLength;
	thePPCReadPBPtr->bufferPtr	= theBufferPtr;

	return PPCRead(thePPCReadPBPtr, TRUE);    // asynchronous
}

// Using the PPCInform function to enable a port to receive sessions
OSErr DoPPCInform(PPCParamBlockPtr	thePPCParamBlockPtr,
						PPCPortPtr	thePPCPortPtr,
						LocationNamePtr	theLocationNamePtr,
						StringPtr	theUserNamePtr,
						PPCPortRefNum	thePortRefNum)
{

	thePPCParamBlockPtr->informParam.ioCompletion	= NULL;
	
	// from the PPCOpen function
	thePPCParamBlockPtr->informParam.portRefNum = thePortRefNum;
	
	thePPCParamBlockPtr->informParam.autoAccept = TRUE;
	thePPCParamBlockPtr->informParam.portName = thePPCPortPtr;
	thePPCParamBlockPtr->informParam.locationName = theLocationNamePtr;
	thePPCParamBlockPtr->informParam.userName = theUserNamePtr;
	
	return PPCInform((PPCInformPBPtr)thePPCParamBlockPtr, TRUE);
	// asynchronous
}


OSErr  DoPPCInit()
{
	long PPCAttributes;	// Attributes to set
	OSErr err;	// Error returned

	err = Gestalt(gestaltPPCToolboxAttr, &PPCAttributes);
	if ( err == noErr )
	{
		// PPC Toolbox is present
		if (  !( PPCAttributes & gestaltPPCSupportsRealTime) )
		{
			// PPC Toolbox needs initialization
			// initialize the PPC Toolbox and set function result
			err = PPCInit();
			// test the attributes for the PPC Toolbox
			err = Gestalt(gestaltPPCToolboxAttr,&PPCAttributes);
		}

		if ( PPCAttributes & gestaltPPCSupportsOutGoing )
			;
			// ports can be opened to the outside world
		else
			
			fprintf(stderr, "AppleTalk is disabled\n");
			// it's likely that AppleTalk is disabled, so you may
			// want to tell the user to activate AppleTalk from
			// the Chooser

		if (PPCAttributes & gestaltPPCSupportsIncoming)
			;
			// ports can be opened with location names that the
			// outside world can see
		else
			fprintf(stderr, "Program linking is disabled. Enable from Sharing Setup\n");
			// it's likely that program linking is disabled, so you
			// may want to tell the user to start program linking
			// from the Sharing Setup control panel
	}
		
	if( err != noErr )
		
		fprintf(stderr, "Error initializing port: %d\n", err);
		
	return err;
}


void ShowPPCBrowser(LocationNameRec *theLocation, PortInfoRec *thePortInfo)
{
	
	short	myErr;
	
	myErr = PPCBrowser("\pSelect a Nachos","\pNachos",FALSE,
						theLocation,thePortInfo, NULL,"\pNACHOS_TYPE");
}

OSErr DoPPCOpen(PPCPortRefNum *thePortRefNum, char *name)

{
	PPCOpenPBRec	thePPCOpenPBRec;
	PPCPortRec		thePPCPortRec;
	LocationNameRec	theLocationNameRec;
	OSErr			err;

	// nameScript and name should be resources to allow easy localization
	thePPCPortRec.nameScript = smRoman;	// Roman script

	// name is a pascal style string, need to cast it to call strcpy
	
	c2pstr(name);
	BlockMove(name, thePPCPortRec.name, name[0]+1 );
	
	// the port type should always be hard-coded to allow the
	// application to find ports of a particular type even after
	// the name is localized
	thePPCPortRec.portKindSelector = ppcByString;

	// name is a pascal style string, need to cast it to call strcpy
	strcpy((char *)thePPCPortRec.u.portTypeStr,"NACHOS_TYPE");
	c2pstr((char *) thePPCPortRec.u.portTypeStr);
	
	
	theLocationNameRec.locationKindSelector = ppcNBPTypeLocation;

	// nbpType is a pascal style string, need to cast it to call strcpy
	strcpy((char *)theLocationNameRec.u.nbpType, "NACHOS_TYPE");
	c2pstr((char *) theLocationNameRec.u.nbpType);
	
	BlockMove(name, theLocationNameRec.u.nbpEntity.objStr, name[0]+1 );
	
	thePPCOpenPBRec.serviceType = ppcServiceRealTime;
	thePPCOpenPBRec.resFlag = 0;    // must be 0 for 7.0+
	thePPCOpenPBRec.portName = &thePPCPortRec;
	thePPCOpenPBRec.locationName  = &theLocationNameRec;

	// make this a visible entity on the network
	thePPCOpenPBRec.networkVisible 	= TRUE;

	err  = PPCOpen(&thePPCOpenPBRec, FALSE);	// synchronous
	*thePortRefNum  = thePPCOpenPBRec.portRefNum;
	
	if( err != noErr )
		
		fprintf(stderr, "Error %d while trying to open a port: %d\n", err );
		
	return err;
}


// Ending a PPC session using the PPCEnd function
OSErr DoPPCEnd(PPCSessRefNum theSessRefNum)
{
	PPCEndPBRec thePPCEndPBRec;

	// Set the Session ref number to pass to PPCEnd
	thePPCEndPBRec.sessRefNum = theSessRefNum;

	// Return result of PPCEnd
	return PPCEnd(&thePPCEndPBRec, FALSE);	// synchronous
}

// Closing a PPC port using the PPCClose function
OSErr DoPPCClose(PPCPortRefNum thePortRefNum)
{
	PPCClosePBRec theClosePBRec;

	// Set the proper portRefNum, which is grabbed from PPCOpen function
	theClosePBRec.portRefNum = thePortRefNum;

	return PPCClose(&theClosePBRec, FALSE);	// synchronous
}

// Initiating a session using the PPCStart function
OSErr DoPPCStart	(PortInfoPtr	thePortInfoPtr,
						LocationNamePtr	theLocationNamePtr,
						PPCPortRefNum	thePortRefNum,
						PPCSessRefNum	*theSessRefNum,
						long		*theUserRefNum,
						long		*theRejectInfo)
{
	PPCStartPBRec	thePPCStartPBRec;
	Str32		userName;
	OSErr		err;
	
	thePPCStartPBRec.ioCompletion	= NULL;
	
	thePPCStartPBRec.portRefNum	= thePortRefNum;
												// from PPCOpen function
	
	thePPCStartPBRec.serviceType	= ppcServiceRealTime;
	
	thePPCStartPBRec.resFlag	= 0;
	
	thePPCStartPBRec.portName	= &thePortInfoPtr->name;
												// destination port
	
	thePPCStartPBRec.locationName	= theLocationNamePtr;
												// destination location
	
	 // application-specific data for PPCInform
 	thePPCStartPBRec.userData = 0;

	 // attempt to log on
	 err = PPCStart(&thePPCStartPBRec, FALSE);

	if ( err == noErr ) {
	   *theSessRefNum  = thePPCStartPBRec.sessRefNum;
	   *theUserRefNum = thePPCStartPBRec.userRefNum;
	}
	else if ( err == userRejectErr )
		// return rejectInfo from the PPCReject function
		*theRejectInfo = thePPCStartPBRec.rejectInfo;
	
	if( err != noErr )
		
		fprintf(stderr, "Error#%d while trying to start a session\n", err);
		
	return err;
}

pascal void FinishWriteSession(PPCWritePBPtr thePPCWritePBPtr ) {
	
	DoPPCEnd( thePPCWritePBPtr->sessRefNum );
}

