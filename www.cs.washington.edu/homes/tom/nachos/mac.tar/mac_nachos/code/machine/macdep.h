void InitializeMacNetwork();
int OpenSocket();
void CloseSocket(int sockID);
void DeAssignNameToSocket(char *socketName);
void AssignNameToSocket(char *name, int sockID);
void ReadFromSocket(int sockID, char *buffer, int packetSize);
void SendToSocket(int sockID, char *buffer, int packetSize, char *toName);
int PollSocket(int sockID);
