#include <Events.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <unix.h>
#include <PPCToolbox.h>

#include "macdep.h"
#include "ppc.h"

//----------------------------------------------------------------------
// ASSERT
//      If condition is false,  print a message and dump core.
//	Useful for documenting assumptions in the code.
//
//	NOTE: needs to be a #define, to be able to print the location 
//	where the error occurred.
//----------------------------------------------------------------------
#define ASSERT(condition)                                                     \
    if (!(condition)) {                                                       \
        fprintf(stderr, "Assertion failed: line %d, file \"%s\"\n",           \
                __LINE__, __FILE__);                                          \
	fflush(stderr);							      \
        exit(0);                                                              \
    }


// Here we create a network abstraction package that can be used with Nachos
#define	kMaxConnections	64

typedef struct __NachosSocket {
	
	PPCPortRefNum	portRefNum;
	PPCInformPBPtr	sessionBlock;
	PPCPortPtr		otherPortInfo;
	LocationNamePtr	otherPortName;
	Str255			otherUserName;
	
} __NachosSocket, *__NachosSocketPtr;

typedef	Boolean	BitArray;

__NachosSocketPtr	__ArNachosSockets[kMaxConnections];
BitArray	__BpPortRefNums[kMaxConnections];
PPCWritePBRec gWriteBlock;
PPCReadPBRec	gReadBlock;
PPCPortRefNum macSockID;

void InitializeBitArray(BitArray *bArray, int size) {
	
	short	i;
	
	for(i = 0; i < size; i++)
		
		bArray[i] = FALSE;
}

void ClearBit(BitArray *bArray, int size, int id) {
	
	ASSERT(id >= 0 && id < size);
	
	bArray[id] = FALSE;
}

int FindBit(BitArray *bArray, int size) {
	
	int	i;
	
	for(i = 0; i < size; i++) {
		
		if(bArray[i] == FALSE) {
			
			bArray[i] = TRUE;
			return(i);
		}
	}
	
	return(-1);
}

void MacInitializeMacNetwork() {
	
	macSockID = -1;
	
	InitializeBitArray(__BpPortRefNums, kMaxConnections);
	
	DoPPCInit();
}

int MacOpenSocket()
{
	int	sockID;
	
	sockID = FindBit(__BpPortRefNums, kMaxConnections);
	ASSERT(sockID != -1);
	
	__ArNachosSockets[sockID] = (__NachosSocketPtr) NewPtr(sizeof(__NachosSocket));
	ASSERT(MemError() == 0);
	__ArNachosSockets[sockID]->sessionBlock = (PPCInformPBPtr) NewPtr(sizeof(PPCInformPBRec));
	__ArNachosSockets[sockID]->sessionBlock->ioResult = 1;
	ASSERT(MemError() == 0);
	__ArNachosSockets[sockID]->otherPortInfo = (PPCPortPtr) NewPtr(sizeof(PPCPortRec));
	ASSERT(MemError() == 0);
	__ArNachosSockets[sockID]->otherPortName = (LocationNamePtr) NewPtr(sizeof(LocationNameRec));
	ASSERT(MemError() == 0);
	
	return(sockID);
}

void MacCloseSocket(int sockID) {
	
	OSErr err;
	
	err = DoPPCClose(__ArNachosSockets[sockID]->portRefNum);
	ASSERT(err == 0);
	
	ClearBit(__BpPortRefNums, kMaxConnections, sockID);
	
	DisposePtr((Ptr) __ArNachosSockets[sockID]->sessionBlock);
	DisposePtr((Ptr) __ArNachosSockets[sockID]->otherPortInfo);
	DisposePtr((Ptr) __ArNachosSockets[sockID]->otherPortName);
	DisposePtr((Ptr) __ArNachosSockets[sockID]);	
}

void MacDeAssignNameToSocket(char *socketName) {
	// do nothing -- the socket is closed using CloseSocket
}

void MacAssignNameToSocket(char *name, int sockID) {
	
	OSErr	err;
	
	err = DoPPCOpen( &(__ArNachosSockets[sockID]->portRefNum), name );
	ASSERT(err == 0);
	
	err = DoPPCInform( (PPCParamBlockPtr) __ArNachosSockets[sockID]->sessionBlock,
					  __ArNachosSockets[sockID]->otherPortInfo,
					  __ArNachosSockets[sockID]->otherPortName,
					  __ArNachosSockets[sockID]->otherUserName, 
					  __ArNachosSockets[sockID]->portRefNum );
	ASSERT(err == 0);
}

int MacReadFromSocket(int sockID, char *buffer, int packetSize) {
		
	OSErr			err;
	EventRecord		theEvent;

	err = DoPPCRead( &gReadBlock, __ArNachosSockets[sockID]->sessionBlock->sessRefNum, 
						packetSize, (char *) buffer );
	ASSERT(err == 0);
	
	while(gReadBlock.ioResult == 1)
	{
		WaitNextEvent( 12, &theEvent, 32000, NULL );
	}
	
	err = DoPPCInform( (PPCParamBlockPtr) __ArNachosSockets[sockID]->sessionBlock,
				  __ArNachosSockets[sockID]->otherPortInfo,
				  __ArNachosSockets[sockID]->otherPortName,
				  __ArNachosSockets[sockID]->otherUserName, 
				  __ArNachosSockets[sockID]->portRefNum );
	ASSERT(err == 0);
	
	return(gReadBlock.actualLength);
}

void MacSendToSocket(int sockID, char *buffer, int packetSize, char *toName) {
	
	OSErr	err;
	PPCSessRefNum gWriteSessionRefNum;
	long		  userRefNum, rejectInfo;
	PortInfoRec		thePortInfo;
	EventRecord	theEvent;
	
	err = DoPPCGetTargetAddress(toName, &thePortInfo,
								 __ArNachosSockets[sockID]->otherPortName );
	ASSERT(err == 0);
	
	err = DoPPCStart( &thePortInfo, 
					  __ArNachosSockets[sockID]->otherPortName,
					  __ArNachosSockets[sockID]->portRefNum,
					  &gWriteSessionRefNum, &userRefNum, &rejectInfo );
	ASSERT(err == 0);
	
	err = DoPPCWrite( &gWriteBlock, gWriteSessionRefNum, packetSize, buffer );
	ASSERT(err == 0);
}
	
int MacPollSocket(int sockID) {

	int i;
	EventRecord theEvent;
	OSErr	err;
	
	if(__ArNachosSockets[sockID]->sessionBlock->ioResult != 1)
	{
		return TRUE;
	}
	
	WaitNextEvent( 12, &theEvent, 32000, NULL );
	
	return FALSE;
}

struct timeval {
	int	tv_sec;
	int tv_usec;
};


int select(int numBits, void *readFds, void *writeFds, void *exceptFds, 
	struct timeval *timeout)
{

	int			curPos, endPos, err;
	EventRecord	theEvent;
	char		buffer[4];
		
	err = read( (int) 0, buffer, numBits/32 );
	ASSERT(err != EOF );
	
	if( err > 0 )	// there is stuff to be read
	{	
		err = write( (int) 0, buffer, err );
		ASSERT(err != EOF );
		
		return(	1 );
	}
	else
	{	
		
		WaitNextEvent( 12, &theEvent, 32000, NULL );
		
		return( 0 );
	}
	
	return(1);

}